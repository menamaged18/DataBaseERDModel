class Loan:
  def __init__(self,id ,type , amount ,customer_id):
   self.id = id
   self.type = type
   self.amount = amount
   self.customer_id = customer_id
   