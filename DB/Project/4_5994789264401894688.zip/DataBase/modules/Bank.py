class Bank:
  def __init__(self, ssn, name,code,address):
    self.ssn = ssn
    self.name = name
    self.code = code
    self.address = address
    


import sqlite3
myDB = sqlite3.connect("app.db")
cursor = myDB.cursor()
def new_Bank():
  name =input("Enter Bank Name: ")
  cursor.execute(f"select * from Bank where name ='{name}'")
  if(len(cursor.fetchall())==1):
   print("This Name Exist!!")
   new_Bank()  
  ssn= input("Enter bank SSN: ")
  cursor.execute(f"select * from Bank where ssn ={ssn}")
  if(len(cursor.fetchall())==1):
    print("This ssn Exist!!")
    new_Bank()  
  code = input("Enter Bank Code: ")
  cursor.execute(f"select * from Bank where code ={code}")
  if(len(cursor.fetchall())==1):
    print("This code Exist!!")
    new_Bank()
  address = input("Enter Bank Address: ")
  cursor.execute(f"select * from Bank where address ='{address}'")
  if(len(cursor.fetchall())==1):
    print("This address Exist!!")
    new_Bank()
  NewObj=Bank(ssn,name,code,address)
  cursor.execute(f"insert into Bank values({NewObj.ssn},'{NewObj.name}',{NewObj.code},'{NewObj.address}')")
  print("operation done successfull") 
