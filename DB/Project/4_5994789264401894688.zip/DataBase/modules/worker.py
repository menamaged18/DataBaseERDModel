class worker:
 def __init__(self,id ,name , address,phone,position,Branch_id):
    self.id = id
    self.address = address
    self.phone=phone
    self.position = position
    self.Branch_id = Branch_id
