class Branch:
  def __init__(self,id , address,Bank_id ):
    self.id = id
    self.address = address
    self.Bank_id = Bank_id


    

import sqlite3
myDB = sqlite3.connect("app.db")
cursor = myDB.cursor()
def new_Branch():
  id =input("Enter Branch id: ")
  cursor.execute(f"select * from Branch where id ='{id}'")
  if(len(cursor.fetchall())==1):
   print("This id Exist!!")
   new_Branch()  
   
  address = input("Enter Branch Address: ")
  cursor.execute(f"select * from Bank where address ='{address}'")
  if(len(cursor.fetchall())==1):
    print("This address Exist!!")
    new_Branch()
  code = input("Enter Bank id: ")
  cursor.execute(f"select * from Bank where ssn ={code}")
  if(len(cursor.fetchall())!=1):
    print("this bank not exist!!")
    new_Branch()
  NewObj = Branch(id,address,code)
  cursor.execute(f"insert into Branch values({NewObj.id},'{NewObj.address}',{NewObj.Bank_id})")
  print("operation done successfull")
  myDB.commit() 

