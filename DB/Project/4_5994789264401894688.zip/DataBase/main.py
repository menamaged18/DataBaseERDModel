from modules import Bank , Account ,Branch ,customer , Loan , worker 

# Bank.new_Bank()

# Branch.new_Branch()

# customer.new_Customer()


